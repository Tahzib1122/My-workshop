mydata <-read.csv("C:/Users/usago/OneDrive/Desktop/Data Science/Dataset_MIdterm_sectoin(A).csv",header=TRUE,sep=",")
mydata

names(mydata)

str(mydata)

mydata$gender<-factor(mydata$gender,levels = c("male", "female"),labels = c(1,0))
mydata


mydata2<-read.csv("C:/Users/usago/OneDrive/Desktop/Data Science/Dataset_MIdterm_sectoin(A).csv",header=TRUE,sep=",")
pressurehight<-data.frame(pressurehight=c(mydata2$pressurehight))
mydata3<-edit(mydata2)
mydata3

missingrow <- mydata[!complete.cases(mydata), ] 
missingrow

which(is.na(mydata$age)) 
which(is.na(mydata$gender)) 
which(is.na(mydata$impluse)) 
which(is.na(mydata$pressurehight))
which(is.na(mydata$pressurelow)) 
which(is.na(mydata$glucose)) 
which(is.na(mydata$class))

colSums(is.na(mydata))


mydata1<-read.csv("C:/Users/usago/OneDrive/Desktop/Data Science/Dataset_MIdterm_sectoin(A).csv",header=TRUE,sep=",")
remove<- na.omit(mydata1)
remove


mydatamean6<-mydata3
mydatamean6$gender<-factor(mydatamean6$gender,levels = c("male", "female"),labels = c(1,0))
mydatamean6$age[is.na(mydatamean6$age)] <- mean(mydatamean6$age, na.rm = TRUE)
mydatamean6$pressurehight[is.na(mydatamean6$pressurehight)] <- mean(mydatamean6$pressurehight, na.rm = TRUE)
mydatamean6

mydatamostfreq<-mydata3
names(which.max(table(mydatamostfreq$age)))
names(which.max(table(mydatamostfreq$gender)))
names(which.max(table(mydatamostfreq$pressurehight)))

mydatamostfreq$age[is.na(mydatamostfreq$age)] <- names(which.max(table(mydatamostfreq$age, useNA = "ifany")))
mydatamostfreq$gender[is.na(mydatamostfreq$gender)] <- names(which.max(table(mydatamostfreq$gender, useNA = "ifany")))
mydatamostfreq$pressurehight[is.na(mydatamostfreq$pressurehight)] <- names(which.max(table(mydatamostfreq$pressurehight, useNA = "ifany")))
mydatamostfreq

summary(mydata3)

hist(mydata$age,main = 'AGE',xlab = 'Age Data',ylab = 'Frequency',xlim = c(1,200),ylim =c(1,100))
hist(mydata$pressurehight,main = 'PressureHight',xlab = 'PressureHight Data',ylab = 'Frequency',xlim = c(1,200),ylim =c(1,150))
hist(mydata$pressurelow,main = 'PressureLow',xlab = 'PressureLow Data',ylab = 'Frequency',xlim = c(1,100),ylim =c(1,50))
hist(mydata$impluse,main = 'Impulse',xlab = 'Impulse Data',ylab = 'Frequency',xlim = c(1,250),ylim =c(1,150))
hist(mydata$glucose,main = 'Glucose',xlab = 'Glucose Data',ylab = 'Frequency',xlim = c(1,400),ylim =c(1,100))

barplot(table(mydata$gender), main = "Bar Chart of Gender", xlab = "Gender", ylab = "Frequency")
barplot(table(mydata$class), main = "Bar Chart of Class", xlab = "Class", ylab = "Frequency")

boxplot(mydata$age,ylab = "Age")
boxplot(mydata$pressurehight,ylab = "pressurehight")
boxplot(mydata$pressurehight,ylab = "pressur low")
boxplot(mydata$glucose,ylab = "Glucose")


